#include <stdio.h>
#include "system.h"
#include "io.h"
#include "altera_avalon_pio_regs.h" //access to PIO macros
#include <stdint.h>
#include "altera_avalon_mutex.h"

// Screen Parameters
 #define SCREEN_WIDTH    320
 #define SCREEN_LENGTH   240
 #define HALF_WIDTH  (SCREEN_WIDTH/2)    // 160
 #define HALF_LENGTH (SCREEN_LENGTH/2)   // 120

// Gyro Write Registers
 #define    BW_RATE        0x2c
 #define    POWER_CONTROL  0x2d
 #define    DATA_FORMAT    0x31
 #define    INT_ENABLE     0x2E
 #define    INT_MAP        0x2F
 #define    THRESH_ACT     0x24
 #define    THRESH_INACT   0x25
 #define    TIME_INACT     0x26
 #define    ACT_INACT_CTL  0x27
 #define    THRESH_FF      0x28
 #define    TIME_FF        0x29
 #define    TAP_AXES       0x2a
 #define    TAP_THRES      0x1d
 #define    LATENT         0x22
 #define    DUR            0x21
 #define    WINDOW         0x23

 // Gyro Read Registers
 #define    INT_SOURCE     0x30
 #define    X_LB           0x32
 #define    X_HB           0x33
 #define    Y_LB           0x34
 #define    Y_HB           0x35
 #define    Z_LB           0x36
 #define    Z_HB           0x37

 #define CONFIG_LENGHT 16 * 2
 #define MAX_COUNT 500000

 #define READ_X_AXIS 0xc0 | X_LB // enable read bit and multi byte
 #define READ_Y_AXIS 0xc0 | Y_LB // enable read bit and multi byte
 #define READ_Z_AXIS 0xc0 | Z_LB // enable read bit and multi byte


// shared memory addresses 3997690
 #define TAP_ADDR         0x00300000
 #define SW_ADDR          0x00300001
 #define X_AXIS_ADDR      0x00300010

 #define SINGLE_ADDR      0x00386488
 #define QUAD_ADDR        0x033A9980
 #define FILTERED_ADDR   0x03000180

// Consumer-relevant addresses
 #define USEC_COUNTER_BASE 0x4001000
 #define PIXEL_BUFF_ADR_BASE 0x4001040
 #define PIXEL_DATA_BASE     0x4001030
 #define HEX2_BASE 0x4001010
 #define HEX5_3_BASE 0x4001020

//variable for rotate function
 #define ROT_THRESH 100
 static int16_t prev_xData = 0;
 static int8_t  rotate_count = 0;

// variable for convolve and edge detect function
 static int image = 1;

// variable for mutex
 alt_mutex_dev* mutex;

unsigned char digit_to_hex[10] = { // array to convert a digit into hex
    0xC0, // 0s
    0xF9, // 1
    0xA4, // 2
    0xB0, // 3
    0x99, // 4
    0x92, // 5
    0x82, // 6
    0xF8, // 7
    0x80, // 8
    0x90  // 9
};

void display_fps(unsigned int frame_time) {
    unsigned int fps = 100000000 / frame_time; // 1000000us/frame_time * 100 <- to display decimal (even if its .00)
    unsigned int digits[4];

    digits[0] = (fps/1000) % 10; // separate fps into individual digits
    digits[1] = (fps/100) % 10;
    digits[2] = (fps/10) % 10;
    digits[3] =  fps % 10;

    unsigned int hex_02 = ((digit_to_hex[digits[1]] << 0) | // display each digit
                          (digit_to_hex[digits[2]] << 8)  | // bit shift to append each hex converted digit
                          (digit_to_hex[digits[3]] << 16))&
                          (0xFFFF7F); // 0xFFFF7F turns on decimal point of hex2

    unsigned int hex_3 = (digit_to_hex[digits[0]] << 16) | (0xFFFF); // 0xFFFF turns off hex4-5

    IOWR(HEX2_BASE, 0, hex_02); // display to hex0-hex2
    IOWR(HEX5_3_BASE, 0, hex_3); // display to hex3-hex5
}

void draw_quadrant(const unsigned char *small_buf, unsigned char *big_buf, int quadrant, int width, int height) {
    int big_width = width * 2;
    int row_off = (quadrant >= 2) ? height : 0;
    int col_off = (quadrant == 1 || quadrant == 2) ? width  : 0;

    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int big_index   = ((row_off + y) * big_width + (col_off + x))*3; //output
            int small_index =  (y * width + x)*3; //src
            big_buf[big_index + 0] = small_buf[small_index + 0]; // R
            big_buf[big_index + 1] = small_buf[small_index + 1]; // G
            big_buf[big_index + 2] = small_buf[small_index + 2]; // B
        }
    }
}



void gaussian_blur(unsigned char *input_image, unsigned char *output_image, int width, int height) {
    for (int y = 1; y < height - 1; y++) {
        for (int x = 1; x < width - 1; x++) {
        	//
            int idx   = y * width + x;
            int idx1  = (y-1) * width + x;
            int idx2  = (y+1) * width + x;

            int sum = input_image[idx1 - 1] + input_image[idx1] + input_image[idx1 + 1] +
                      input_image[idx  - 1] + input_image[idx ] + input_image[idx  + 1] +
                      input_image[idx2 - 1] + input_image[idx2] + input_image[idx2 + 1];

            // use fixed-point approximation instead (integer math)
            output_image[idx] = (sum * 7282) >> 16;
        }
    }

	 // border 0s
	 //top border and bottom border with corners
	 for(int k=0; k < width; k++){
		 output_image[k]=0; //top border
		 output_image[width*(height-1)+k]=0; //bottom border ->
	 }
	 // first col and last col without corners
	 for(int l=1; l<height-1;l++){
		 output_image[width*l]=0; // first col
		 output_image[width*l+(width-1)]=0; // last col
	 }
}


void gaussian_blur_rbg(unsigned char *input_image, unsigned char *output_image, int width, int height) {
    int num_pixels = width * height;
    uint8_t colour[num_pixels];      // Temporary buffer for current color channel
    uint8_t colour_blur[num_pixels]; // Output of blurred channel

    for (int c = 0; c < 3; c++) {  // c = 0 (Red), 1 (Green), 2 (Blue)
        // Extract channel
        for (int i = 0; i < num_pixels; i++) {
        	colour[i] = input_image[3 * i + c] & 0x0F;
        }

        // Apply blur to this channel
        gaussian_blur(colour, colour_blur, width, height);

        // Store blurred channel back into output
        for (int i = 0; i < num_pixels; i++) {
            output_image[3 * i + c] = colour_blur[i];
        }
    }
}


void edge_detect(unsigned char *inputImage, unsigned char *outputImage, int width, int height) {
		for (int y = 1; y < height-1; y++) {
			for (int x = 1; x < width-1; x++) {
				int idx = y * width + x;
				// calculating and storing row offsets - optimise
				int top_row = (y-1)*width;
				int current_row = y*width;
				int below_row = (y+1)*width;

				int gX = -inputImage[top_row + (x-1)] - 2*inputImage[current_row + (x-1)] - inputImage[below_row + (x-1)]
					+ inputImage[top_row + (x+1)] + 2*inputImage[current_row + (x+1)] + inputImage[below_row + (x+1)];

				int gY = -inputImage[top_row + (x-1)] - 2*inputImage[top_row + x] - inputImage[top_row + (x+1)]
				     + inputImage[below_row + (x-1)] + 2*inputImage[below_row + x] + inputImage[below_row + (x+1)];

				int sum = (abs(gX) + abs(gY) > 10) * 15;

				outputImage[idx] = (unsigned char)sum;
			}
		}
}

void EDGE_RGB_GREYSCALE(unsigned char * input_image, unsigned char * output_image, int width, int height){
	//converts RGB for each pixel back into Grey so from 3 bytes per pixel back to 1
	for (int i = 0; i< width * height; i++){
		uint8_t R = input_image[3*i + 0]& 0x0F;
		uint8_t G = input_image[3*i + 1]& 0x0F;
		uint8_t B = input_image[3*i + 2]& 0x0F;
		output_image[i] = (uint8_t)(0.299 * R + 0.587 * G + 0.114 * B);
	}
}
void RGB_EDGE(unsigned char * input_image, unsigned char * output_image, int width, int height){
	//converts RGB for each pixel back into Grey so from 3 bytes per pixel back to 1
	for (int i = 0; i< width * height; i++){
		uint8_t value = input_image[i]; // input will be grey img with value from 0 to 15
		input_image[i] = value;
		output_image[3*i + 0] = value; //R
		output_image[3*i + 1] = value; //G
		output_image[3*i + 2] = value; //B
	}
}


void image_flip(unsigned char * input_image, unsigned char * output_image, int width, int height){
     // swap around addresses of pixels
     //or
     // swap around the columns -> do this for implementation simplicity-> confirm w task 3?
     for (int i = 0; i<height ; i++){
         for( int j = 0; j<width;j++){
             int output_index = i*width+j;
			 int input_index = (height-1-i)*width+(width-1-j);
             //Just taking Single Image which is stored like so [RRRRGGGGBBBB] indexing R G B
			 //Flipping the Location of those R G B values
             output_image[output_index*3 + 0] = input_image[input_index*3 + 0]; //R
             output_image[output_index*3 + 1] = input_image[input_index*3 + 1]; //G
			 output_image[output_index*3 + 2] = input_image[input_index*3 + 2]; //B
         }
     }
}

void single_mode() {
	 unsigned int start_time = IORD(USEC_COUNTER_BASE, 0);
	 unsigned char single_image_data[76800*3];

	 //image = IORD(IMAGE_FILTER_ADRESS,0);   // 1=default, 2=flip, 3=blur, 4=edge_detect
     static int double_tap  = 0;


     // lock
     altera_avalon_mutex_lock(mutex, 1);

     //read double tap source
     double_tap = IORD(TAP_ADDR, 0); // if 1, then double_tap is is registered
     printf("double tap = %i\n", double_tap);
     if ((double_tap == 1)) {
    	 IOWR(TAP_ADDR, 0, 0);
    	 image = (image % 4) + 1;
         printf("Image generated: %d \n", image);
     }

     //unlock
     altera_avalon_mutex_unlock(mutex);

     // lock
     altera_avalon_mutex_lock(mutex, 1);

     // read single image data
     for (int i=0; i<(SCREEN_WIDTH*SCREEN_LENGTH*3); i++){
    	 single_image_data[i] = IORD(SINGLE_ADDR,i);
     }

     //unlock
     altera_avalon_mutex_unlock(mutex);

     static unsigned char filtered_fullsize_buffer[SCREEN_WIDTH * SCREEN_LENGTH *3]; //For a 3 channel output
     static unsigned char gray_image[SCREEN_WIDTH * SCREEN_LENGTH]; //store grey pixels (only need 76800)
     static unsigned char Output_Edge[SCREEN_WIDTH * SCREEN_LENGTH];
     switch (image) {
       case 1:  //default
         memcpy(filtered_fullsize_buffer, single_image_data, SCREEN_WIDTH * SCREEN_LENGTH*3);
         break;
       case 2:  //flip
         image_flip(single_image_data, filtered_fullsize_buffer, SCREEN_WIDTH, SCREEN_LENGTH);
         break;
       case 3:  //blur
    	   gaussian_blur_rbg(single_image_data,filtered_fullsize_buffer, SCREEN_WIDTH, SCREEN_LENGTH);
         break;
       case 4:  //edge_detect
    	 EDGE_RGB_GREYSCALE(single_image_data, gray_image,SCREEN_WIDTH, SCREEN_LENGTH); //USE RGB TO CONVERT INTO GREYSCALE
         edge_detect(gray_image, Output_Edge, SCREEN_WIDTH, SCREEN_LENGTH);				//RUN EDGE DETECTION ON GREYSCALE
         RGB_EDGE(Output_Edge, filtered_fullsize_buffer , SCREEN_WIDTH, SCREEN_LENGTH);	//USE OUTPUT TO CONVERT BACK TO RGB
         break;
     }


     altera_avalon_mutex_lock(mutex, 1);
     for (int i = 0; i < SCREEN_WIDTH * SCREEN_LENGTH * 3; i++) {
			 IOWR(FILTERED_ADDR, i, filtered_fullsize_buffer[i]);
	 }
     altera_avalon_mutex_unlock(mutex);

     //set TX1 high (let 3rd proc start displaying image)
     IOWR(TX1_BASE,0, 0b10);

     unsigned int end_time = IORD(USEC_COUNTER_BASE, 0);
     unsigned int frame_time = end_time - start_time; // frame time in microseconds
     display_fps(frame_time); // display fps onto hex
}

void quad_mode() {
	// read switch data
     unsigned int sw = IORD(SW_ADDR, 0);

     int selected_image = -1;

     unsigned char quad_image_data[19200*3];
     unsigned char big_buffer [76800*3];
     unsigned char convolve_buffer[19200*3];
     unsigned char image_flip_buffer[19200*3];
     unsigned char grey_buffer[HALF_WIDTH * HALF_LENGTH];
     unsigned char edge_detection_buffer[19200];
     unsigned char rgb_edge_detection_buffer[19200*3];

     unsigned int start_time = IORD(USEC_COUNTER_BASE, 0);

     alt_16 xData = IORD(X_AXIS_ADDR, 0);

     if (xData > ROT_THRESH && prev_xData <= ROT_THRESH) {
         rotate_count++;    //clockwise
     }
     else if (xData < -ROT_THRESH && prev_xData >= -ROT_THRESH) {
         rotate_count--;    //anti-clockwise
     }
     prev_xData = xData;

     printf("X axis: %4d\trotate_count: %d\n", xData, rotate_count);

     // read quad mode image data
     altera_avalon_mutex_lock(mutex, 1);

     for (int i=0; i<(HALF_WIDTH*HALF_LENGTH*3); i++){
         	 quad_image_data[i] = IORD(QUAD_ADDR,i);
          }

     // unlock
      altera_avalon_mutex_unlock(mutex);

     if ((sw & 0x01) != 0) {
         selected_image = 0;
         printf("Default image selected\n");
     } else if ((sw & 0x02) != 0) {
         selected_image = 1;
         printf("Second image selected\n");
     } else if ((sw & 0x04) != 0) {
         selected_image = 2;
         printf("Third image selected\n");
     } else if ((sw & 0x08) != 0) {
         selected_image = 3;
         printf("Fourth image selected\n");
     } else {  // sw == 0
         selected_image = 4;
         printf("All images selected\n");
     }

     unsigned char *quadrant_buffer[4];
     switch (selected_image) {
         case 0: //Default in all 4 quadrant
             quadrant_buffer[0] = quad_image_data;
             quadrant_buffer[1] = quad_image_data;
             quadrant_buffer[2] = quad_image_data;
             quadrant_buffer[3] = quad_image_data;
             break;
         case 1: // blur in all 4 quadrants
        	 gaussian_blur_rbg(quad_image_data, convolve_buffer, HALF_WIDTH, HALF_LENGTH);
             for (int i = 0; i < 4; i++) quadrant_buffer[i] = convolve_buffer;
             break;
         case 2: //flip in all 4 quadrants
             image_flip(quad_image_data, image_flip_buffer, HALF_WIDTH, HALF_LENGTH);
             for (int i = 0; i < 4; i++) quadrant_buffer[i] = image_flip_buffer;
             break;
         case 3: //Edge detection in all 4 quadrants
        	 EDGE_RGB_GREYSCALE(quad_image_data, grey_buffer, HALF_WIDTH, HALF_LENGTH);
        	 edge_detect(grey_buffer, edge_detection_buffer, HALF_WIDTH, HALF_LENGTH);
        	 RGB_EDGE(edge_detection_buffer, rgb_edge_detection_buffer , HALF_WIDTH, HALF_LENGTH);
             for (int i = 0; i < 4; i++) quadrant_buffer[i] = rgb_edge_detection_buffer;
             break;
         case 4: //all 4 quadrant

        	 gaussian_blur_rbg(quad_image_data, convolve_buffer, HALF_WIDTH, HALF_LENGTH);
             image_flip(quad_image_data, image_flip_buffer, HALF_WIDTH, HALF_LENGTH);

             EDGE_RGB_GREYSCALE(quad_image_data, grey_buffer, HALF_WIDTH, HALF_LENGTH);
             edge_detect(grey_buffer, edge_detection_buffer, HALF_WIDTH, HALF_LENGTH);
             RGB_EDGE(edge_detection_buffer, rgb_edge_detection_buffer , HALF_WIDTH, HALF_LENGTH);

             quadrant_buffer[0] = quad_image_data;  //default
             quadrant_buffer[1] = convolve_buffer; //blur
             quadrant_buffer[2] = image_flip_buffer; //img_flip
             quadrant_buffer[3] = rgb_edge_detection_buffer; //edge
             break;
     }


     unsigned char *map_buf[4];
     for (int q = 0; q < 4; q++) {
         int idx = ((q + rotate_count) % 4 + 4) % 4;
         map_buf[q] = quadrant_buffer[idx];
     }


     for (int q = 0; q < 4; q++) {
         draw_quadrant(map_buf[q], big_buffer, q, HALF_WIDTH, HALF_LENGTH);
     }

     altera_avalon_mutex_lock(mutex, 1);
     for (int i = 0; i < SCREEN_WIDTH * SCREEN_LENGTH * 3; i++) {
			 IOWR(FILTERED_ADDR, i, big_buffer[i]);
	 }
     altera_avalon_mutex_unlock(mutex);

     //set TX1 high (let 3rd proc start displaying image)
     IOWR(TX1_BASE,0, 0b11);

     unsigned int end_time = IORD(USEC_COUNTER_BASE, 0);
     unsigned int frame_time = end_time - start_time; // frame time in microseconds
     display_fps(frame_time); // display fps onto hex
 }

int main(){
	printf("Proc 2 starting.. \n");

	alt_mutex_dev* mutex = altera_avalon_mutex_open(MUTEX_0_NAME);

	// main loop
	while (1){
		int rx1 = IORD(RX1_BASE, 0);
		if (!mutex){
			    printf("Proc 2 failed to unlock mutex\n");
			    return 0;
			}
		// read rX1
		//printf("Ready: %d\n", rx1);
		int mode = (rx1 && 0x01); // 3rd bit is mode
		if (mode == 0){
			single_mode();
			//printf("Single Mode selected\n");

	 	} else if (mode == 1) {
	        printf("Quad Mode selected\n");
	        quad_mode();
	    }
	}


	return 0;
}
