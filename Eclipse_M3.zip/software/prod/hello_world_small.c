#include <stdio.h>
#include "system.h"
#include "io.h"
#include "altera_avalon_pio_regs.h" //access to PIO macros
#include <altera_avalon_spi.h>
#include <altera_avalon_spi_regs.h>
#include <stdint.h>
#include "altera_avalon_mutex.h"

// Screen Parameters
 #define SCREEN_WIDTH    320
 #define SCREEN_LENGTH   240
 #define HALF_WIDTH  (SCREEN_WIDTH/2)    // 160
 #define HALF_LENGTH (SCREEN_LENGTH/2)   // 120
 #define PACKED_SINGLE_SIZE ((SCREEN_WIDTH*SCREEN_LENGTH)/2)*3 //RGB PACKED 4R, 4G, 4B (115200 pixels)
 #define UNPACKED_SINGLE_SIZE SCREEN_WIDTH*SCREEN_LENGTH*3 //UNPACKED IS NOW  230 400 becuase, we need to store R,G,B for every pixel
 #define PACKED_QUAD_SIZE ((HALF_WIDTH*HALF_LENGTH)/2)*3
 #define UNPACKED_QUAD_SIZE HALF_WIDTH*HALF_LENGTH*3

// Gyro Write Registers
 #define    BW_RATE        0x2c
 #define    POWER_CONTROL  0x2d
 #define    DATA_FORMAT    0x31
 #define    INT_ENABLE     0x2E
 #define    INT_MAP        0x2F
 #define    THRESH_ACT     0x24
 #define    THRESH_INACT   0x25
 #define    TIME_INACT     0x26
 #define    ACT_INACT_CTL  0x27
 #define    THRESH_FF      0x28
 #define    TIME_FF        0x29
 #define    TAP_AXES       0x2a
 #define    TAP_THRES      0x1d
 #define    LATENT         0x22
 #define    DUR            0x21
 #define    WINDOW         0x23

// Gyro Read Registers
 #define    INT_SOURCE     0x30
 #define    X_LB           0x32
 #define    X_HB           0x33
 #define    Y_LB           0x34
 #define    Y_HB           0x35
 #define    Z_LB           0x36
 #define    Z_HB           0x37

 #define CONFIG_LENGHT 16 * 2
 #define MAX_COUNT 500000

 #define READ_X_AXIS 0xc0 | X_LB // enable read bit and multi byte
 #define READ_Y_AXIS 0xc0 | Y_LB // enable read bit and multi byte
 #define READ_Z_AXIS 0xc0 | Z_LB // enable read bit and multi byte

// shared memory addresses 3997690
 #define TAP_ADDR         0x00300000
 #define SW_ADDR          0x00300001
 #define X_AXIS_ADDR      0x00300010

 #define SINGLE_ADDR      0x00386488
 #define QUAD_ADDR        0x033A9980
 #define FILTERED_ADDR   0x03000180


alt_mutex_dev* mutex;

alt_u8 gyro_config[CONFIG_LENGHT] = {
    DATA_FORMAT, 0x0b,    // 4-wire SPI, full resolution, +/- 16g
    THRESH_ACT, 0x04,
    THRESH_INACT, 0x02,
    TIME_INACT, 0x02,
    ACT_INACT_CTL, 0xff,
    THRESH_FF, 0x09,
    TIME_FF, 0x46,
    TAP_THRES, 0x20, // TAP THRESH 3g
    TAP_AXES, 0x07, //enable x y z for tap detection
    LATENT, 0x85,  ////Maximum time after first tap before  look for second tap
    DUR, 0x40, //TIme above threshold
    WINDOW, 0xc0, //240ms, Between First and Second tap
    BW_RATE, 0x0a,
    INT_ENABLE, 0x20, //send 00100000 to INT enable to enable bit 5 (double tap)
    INT_MAP, 0x20, //send to Bit 5 to enable INT2 (00100000)
    POWER_CONTROL, 0x08
  };

// set gyro interrupt
void gyro_isr(void * context)
{
    // clear edge capture interrupt to acknowledge and dismiss the interrupt so we dont call it again, prevents
    //isr being called again for the same interrupt
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(INT2_BASE,0);
    printf("Gyro Interrupt!\n");
    //Manually clear edge capture register which lies at PIO +3 offset
    IOWR(INT2_BASE, 3, 0);
}


//set key interrupt
volatile int flag = 0;
void key_isr(void * context2)
{
	int value = IORD(KEY2_BASE, 0) & 0x01; // check the bits
    IOWR(KEY2_BASE, 3,0); // clear the interrupt
    if (value == 1) {
    	flag = 1;
    }

}

void single_mode() {

    alt_u8 targetAddress = INT_SOURCE | 0x80;
    static alt_u8 prev_int_state = 0;
    alt_u8 regData;
    int tap_flag = 0;

    //read interrupt source
    alt_avalon_spi_command(SPI_0_BASE, 1, 1, &targetAddress, 1, &regData, 0);
    if ((regData & 0x20)&& !(prev_int_state & 0x20)) {
    	tap_flag=1;
        printf("Double Tap Detected!\n");
    }

    prev_int_state = regData;

    static alt_u8 send_fullsize_buffer = 0x15; // 0x10 -> 0x14 for packed mode -> 0x15 packed + RGB
    unsigned char packed_buffer[PACKED_SINGLE_SIZE];
    unsigned char receive_fullsize_buffer[UNPACKED_SINGLE_SIZE]; //still 76800*3 = UNPACKED_SINGLE_SIZE (unpacked)
    alt_avalon_spi_command(SPI_0_BASE, 0, 1, &send_fullsize_buffer, PACKED_SINGLE_SIZE-1, packed_buffer+1, 0); //Write RGB values to packed buffer

    for (int i = 0; i < ((SCREEN_WIDTH * SCREEN_LENGTH)/2); i++) { // one iteration needs to read 3 bytes from packed buffer, and unpack them into 2 pixels worth of RGB

    	uint8_t byte0 = packed_buffer[3*i + 0]; //byte 0 will recieve Red[7:4], Green[3:0]
    	uint8_t byte1 = packed_buffer[3*i + 1]; //byte 1 will receive Blue[7:4], Red[3:0]
    	uint8_t byte2 = packed_buffer[3*i + 2]; //byte 2 will recieve green[7:4], Blue[3:0]

    	// Pixel 2 FIRST
    	receive_fullsize_buffer[6*i]   = byte1 & 0xF;         // R low (pixel 2)
    	receive_fullsize_buffer[6*i+1] = (byte2 >> 4) & 0xF;  // G high
    	receive_fullsize_buffer[6*i+2] = byte2 & 0xF;         // B low

    	// Pixel 1 SECOND
    	receive_fullsize_buffer[6*i+3] = (byte0 >> 4) & 0xF;  // R high (pixel 1)
    	receive_fullsize_buffer[6*i+4] = byte0 & 0xF;         // G low
    	receive_fullsize_buffer[6*i+5] = (byte1 >> 4) & 0xF;  // B high
    }

    altera_avalon_mutex_lock(mutex,1);

    // write image buffer data
    for (int i = 0; i<UNPACKED_SINGLE_SIZE; i++){
    	IOWR(SINGLE_ADDR,i,receive_fullsize_buffer[i]);
    }

    // write tap flag data
    if (tap_flag) {
        IOWR(TAP_ADDR, 0, 1);
    }

    altera_avalon_mutex_unlock(mutex);

    IOWR(TX0_BASE,0, 0b10); // signal to consumer
}


void quad_mode() {
    unsigned int sw = IORD(SW9_BASE, 0);
    alt_u8 readX = READ_X_AXIS;
    alt_16 xData;
    unsigned char packed_buffer[PACKED_QUAD_SIZE];
    unsigned char default_buffer[UNPACKED_QUAD_SIZE];
    char Send = 0x17; // 0x12 -> 0x16 for packed mode -> 0x17 for RGB

    // print and read X data
    alt_avalon_spi_command(SPI_0_BASE, 1, 1, &readX, 2, &xData, 0);
    printf("X-data = %d\n", xData);

    // load image into default buffer
    alt_avalon_spi_command(SPI_0_BASE, 0, 1, &Send, PACKED_QUAD_SIZE-1, packed_buffer+1, 0);
    for (int i = 0; i < (HALF_WIDTH*HALF_LENGTH)/2; i++) {

    	uint8_t byte0 = packed_buffer[3*i + 0]; //byte 0 will recieve Red[7:4], Green[3:0]
    	uint8_t byte1 = packed_buffer[3*i + 1]; //byte 1 will receive Blue[7:4], Red[3:0]
    	uint8_t byte2 = packed_buffer[3*i + 2]; //byte 2 will recieve green[7:4], Blue[3:0]


    	// Pixel 2 FIRST
    	default_buffer[6*i]   = byte1 & 0xF;         // R low (pixel 2)
    	default_buffer[6*i+1] = (byte2 >> 4) & 0xF;  // G high
    	default_buffer[6*i+2] = byte2 & 0xF;         // B low

    	// Pixel 1 SECOND
    	default_buffer[6*i+3] = (byte0 >> 4) & 0xF;  // R high (pixel 1)
    	default_buffer[6*i+4] = byte0 & 0xF;         // G low
    	default_buffer[6*i+5] = (byte1 >> 4) & 0xF;  // B high

    }

    altera_avalon_mutex_lock(mutex,1);

    // write image buffer data
    for (int i = 0; i<UNPACKED_QUAD_SIZE; i++){
    	IOWR(QUAD_ADDR,i,default_buffer[i]);
    }

    // write x data
    IOWR(X_AXIS_ADDR,0,xData);

    // write switch data
    IOWR(SW_ADDR,0,sw);

    altera_avalon_mutex_unlock(mutex);

    IOWR(TX0_BASE,0, 0b11); // signal to consumer

   }

int main()
{
	printf("Starting Proc 1...\n");

	// ---- Initialize Mutex ----
	mutex = altera_avalon_mutex_open("/dev/mutex_0");

	// ---- Initialize Gyro IRS ----
	alt_u8 gyro_data_out;
	for (int i = 0; i < CONFIG_LENGHT; i += 2) // load config into module
	{
		alt_avalon_spi_command(SPI_0_BASE, 1, 2, gyro_config + i, 0, &gyro_data_out, 0);

	}

	alt_16 xData;
	alt_u8 isrRes = 0xff;

	void* context = (void *) &isrRes;

	IOWR(INT2_BASE, 3, 0);
	IOWR(INT2_BASE, 2, 0x2);

	int gyroISR_res = alt_ic_isr_register(INT2_IRQ_INTERRUPT_CONTROLLER_ID,INT2_IRQ,gyro_isr, context, 0x0);

	alt_u8 readX = READ_X_AXIS;

	// ---- Initialize Key IRS ----
	void* context2 = 0;
	alt_ic_isr_register(KEY2_IRQ_INTERRUPT_CONTROLLER_ID,KEY2_IRQ,key_isr, context2, 0x0);

	IOWR(KEY2_BASE, 3, 0); // clear interrupt capture register
	IOWR(KEY2_BASE, 2, 0x3); // enable bits 0 and 1


	// ---- START -----
	int mode = 0;
	int prev_flag = 0;
	printf("Flag = %d\n", flag);
	unsigned int initial = 1;
	while (1){
		int ready = IORD(RX0_BASE,0);


		if (flag && !prev_flag) { // if key is pressed, switch mode
			mode = !mode;
		    flag = 0;
		}

		prev_flag = flag;

		if (ready || initial) { // if given OK from consumer (or initial is 1)
			initial=0;
		    if (mode == 0) {
		    	printf("Single Mode selected\n");
		        single_mode();
		    } else {
		    	printf("Quad Mode selected\n");
		        quad_mode();
		    }
		}

	}

  return 0;
}
