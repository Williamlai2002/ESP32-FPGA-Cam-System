#include <stdio.h>
#include "system.h"
#include "io.h"
#include "altera_avalon_pio_regs.h" //access to PIO macros
#include <stdint.h>
#include "altera_avalon_mutex.h"

// Screen Parameters
 #define SCREEN_WIDTH    320
 #define SCREEN_LENGTH   240
 #define HALF_WIDTH  (SCREEN_WIDTH/2)    // 160
 #define HALF_LENGTH (SCREEN_LENGTH/2)   // 120
 #define PACKED_SINGLE_SIZE ((SCREEN_WIDTH*SCREEN_LENGTH)/2)*3 //RGB PACKED 4R, 4G, 4B (115200 pixels)
 #define UNPACKED_SINGLE_SIZE SCREEN_WIDTH*SCREEN_LENGTH*3 //UNPACKED IS NOW  230 400 becuase, we need to store R,G,B for every pixel
 #define PACKED_QUAD_SIZE ((HALF_WIDTH*HALF_LENGTH)/2)*3
 #define UNPACKED_QUAD_SIZE HALF_WIDTH*HALF_LENGTH*3

// shared memory addresses 3997690
 #define TAP_ADDR         0x00300000
 #define SW_ADDR          0x00300001
 #define X_AXIS_ADDR      0x00300010

 #define SINGLE_ADDR      0x00386488
 #define QUAD_ADDR        0x033A9980
 #define FILTERED_ADDR   0x03000180

// Proc3-relevant addresses
 #define RX2_BASE 0x4001010
 #define TX2_BASE 0x4001000
 #define PIXEL_BUFF_ADR_BASE 0x4001040
 #define PIXEL_DATA_BASE 0x4001030


// variable for mutex
 alt_mutex_dev* mutex;

void single_mode() {

	 unsigned char single_image_data[UNPACKED_SINGLE_SIZE];

     // lock
     altera_avalon_mutex_lock(mutex, 1);

     // read single image data
     for (int i=0; i<(SCREEN_WIDTH*SCREEN_LENGTH*3); i++){
    	 single_image_data[i] = IORD(FILTERED_ADDR,i);
     }

     //unlock
     altera_avalon_mutex_unlock(mutex);

     //set tx2 high (let producer load the next image)
     IOWR(TX2_BASE,0, 1);

     for (int i = 0; i < SCREEN_WIDTH * SCREEN_LENGTH; i++) {
    	     uint8_t R = single_image_data[3*i + 0] & 0x0F;
    	     uint8_t G = single_image_data[3*i + 1] & 0x0F;
    	     uint8_t B = single_image_data[3*i + 2] & 0x0F;
    	     uint16_t pixel = (R << 8) | (G << 4) | B;

    	     IOWR(PIXEL_BUFF_ADR_BASE, 0, i);
    	     IOWR(PIXEL_DATA_BASE, 0, pixel);
     }



}

void quad_mode() {
     // read quad mode image data
	unsigned char quad_image_data[UNPACKED_SINGLE_SIZE];

     altera_avalon_mutex_lock(mutex, 1);

     for (int i=0; i<(SCREEN_WIDTH * SCREEN_LENGTH * 3); i++){
         	 quad_image_data[i] = IORD(FILTERED_ADDR,i);
          }

     // unlock
      altera_avalon_mutex_unlock(mutex);

      //set tx2 high (let producer load the next image)
      IOWR(TX2_BASE,0, 1);

      for (int i = 0; i < SCREEN_WIDTH * SCREEN_LENGTH; i++) {
     	     uint8_t R = quad_image_data[3*i + 0] & 0x0F;
     	     uint8_t G = quad_image_data[3*i + 1] & 0x0F;
     	     uint8_t B = quad_image_data[3*i + 2] & 0x0F;
     	     uint16_t pixel = (R << 8) | (G << 4) | B;

     	     IOWR(PIXEL_BUFF_ADR_BASE, 0, i);
     	     IOWR(PIXEL_DATA_BASE, 0, pixel);
      }


 }



int main(){
	printf("Proc 3 starting.. \n");

	alt_mutex_dev* mutex = altera_avalon_mutex_open(MUTEX_0_NAME);

	// main loop
	while (1){
		int rx2 = IORD(RX2_BASE, 0);
		if (!mutex){
			    printf("Proc Edge Detect failed to unlock mutex\n");
			    return 0;
			}

		//printf("Ready: %d\n", rx2);
		int mode = (rx2 && 0x01); // 3rd bit is mode
		if (mode == 0){
			printf("Single Mode selected\n");
			single_mode();

	 	} else if (mode == 1) {
	        printf("Quad Mode selected\n");
	        quad_mode();
	    }
	}


	return 0;
}
